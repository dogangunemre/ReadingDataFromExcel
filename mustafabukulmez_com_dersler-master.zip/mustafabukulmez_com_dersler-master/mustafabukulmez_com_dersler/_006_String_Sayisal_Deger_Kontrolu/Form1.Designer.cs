﻿namespace mustafabukulmez_com_dersler._006_String_Sayisal_Deger_Kontrolu
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_Deger = new System.Windows.Forms.TextBox();
            this.btn_kontrol_et = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl_durum = new System.Windows.Forms.Label();
            this.btn_kontrol_et_2 = new System.Windows.Forms.Button();
            this.btn_kontrol_et_3 = new System.Windows.Forms.Button();
            this.btn_kontrol_et_4 = new System.Windows.Forms.Button();
            this.btn_kontrol_et_5 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txt_Deger
            // 
            this.txt_Deger.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txt_Deger.Location = new System.Drawing.Point(37, 107);
            this.txt_Deger.Name = "txt_Deger";
            this.txt_Deger.Size = new System.Drawing.Size(589, 27);
            this.txt_Deger.TabIndex = 0;
            // 
            // btn_kontrol_et
            // 
            this.btn_kontrol_et.Location = new System.Drawing.Point(37, 157);
            this.btn_kontrol_et.Name = "btn_kontrol_et";
            this.btn_kontrol_et.Size = new System.Drawing.Size(113, 49);
            this.btn_kontrol_et.TabIndex = 1;
            this.btn_kontrol_et.Text = "Kontrol Et 1";
            this.btn_kontrol_et.UseVisualStyleBackColor = true;
            this.btn_kontrol_et.Click += new System.EventHandler(this.btn_kontrol_et_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(37, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Değer";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(37, 258);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Durum : ";
            // 
            // lbl_durum
            // 
            this.lbl_durum.AutoSize = true;
            this.lbl_durum.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_durum.Location = new System.Drawing.Point(126, 258);
            this.lbl_durum.Name = "lbl_durum";
            this.lbl_durum.Size = new System.Drawing.Size(24, 20);
            this.lbl_durum.TabIndex = 4;
            this.lbl_durum.Text = "...";
            // 
            // btn_kontrol_et_2
            // 
            this.btn_kontrol_et_2.Location = new System.Drawing.Point(156, 157);
            this.btn_kontrol_et_2.Name = "btn_kontrol_et_2";
            this.btn_kontrol_et_2.Size = new System.Drawing.Size(113, 49);
            this.btn_kontrol_et_2.TabIndex = 5;
            this.btn_kontrol_et_2.Text = "Kontrol Et 2";
            this.btn_kontrol_et_2.UseVisualStyleBackColor = true;
            this.btn_kontrol_et_2.Click += new System.EventHandler(this.btn_kontrol_et_2_Click);
            // 
            // btn_kontrol_et_3
            // 
            this.btn_kontrol_et_3.Location = new System.Drawing.Point(275, 157);
            this.btn_kontrol_et_3.Name = "btn_kontrol_et_3";
            this.btn_kontrol_et_3.Size = new System.Drawing.Size(113, 49);
            this.btn_kontrol_et_3.TabIndex = 6;
            this.btn_kontrol_et_3.Text = "Kontrol Et 3";
            this.btn_kontrol_et_3.UseVisualStyleBackColor = true;
            this.btn_kontrol_et_3.Click += new System.EventHandler(this.btn_kontrol_et_3_Click);
            // 
            // btn_kontrol_et_4
            // 
            this.btn_kontrol_et_4.Location = new System.Drawing.Point(394, 157);
            this.btn_kontrol_et_4.Name = "btn_kontrol_et_4";
            this.btn_kontrol_et_4.Size = new System.Drawing.Size(113, 49);
            this.btn_kontrol_et_4.TabIndex = 7;
            this.btn_kontrol_et_4.Text = "Kontrol Et 4 ";
            this.btn_kontrol_et_4.UseVisualStyleBackColor = true;
            this.btn_kontrol_et_4.Click += new System.EventHandler(this.btn_kontrol_et_4_Click);
            // 
            // btn_kontrol_et_5
            // 
            this.btn_kontrol_et_5.Location = new System.Drawing.Point(513, 157);
            this.btn_kontrol_et_5.Name = "btn_kontrol_et_5";
            this.btn_kontrol_et_5.Size = new System.Drawing.Size(113, 49);
            this.btn_kontrol_et_5.TabIndex = 8;
            this.btn_kontrol_et_5.Text = "Kontrol Et 5";
            this.btn_kontrol_et_5.UseVisualStyleBackColor = true;
            this.btn_kontrol_et_5.Click += new System.EventHandler(this.btn_kontrol_et_5_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(37, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(331, 25);
            this.label3.TabIndex = 9;
            this.label3.Text = "C# String Sayısal Değer Kontrolü";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(685, 287);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btn_kontrol_et_5);
            this.Controls.Add(this.btn_kontrol_et_4);
            this.Controls.Add(this.btn_kontrol_et_3);
            this.Controls.Add(this.btn_kontrol_et_2);
            this.Controls.Add(this.lbl_durum);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_kontrol_et);
            this.Controls.Add(this.txt_Deger);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_Deger;
        private System.Windows.Forms.Button btn_kontrol_et;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbl_durum;
        private System.Windows.Forms.Button btn_kontrol_et_2;
        private System.Windows.Forms.Button btn_kontrol_et_3;
        private System.Windows.Forms.Button btn_kontrol_et_4;
        private System.Windows.Forms.Button btn_kontrol_et_5;
        private System.Windows.Forms.Label label3;
    }
}