﻿namespace mustafabukulmez_com_dersler._023_XML_Islemleri
{
    partial class XML_Diger_Islemler
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_dataset_ile_olustur = new System.Windows.Forms.Button();
            this.btn_xml_den_dataset = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btn_xml_de_ara = new System.Windows.Forms.Button();
            this.txt_aranacak_metin = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_sonuc = new System.Windows.Forms.Label();
            this.btn_xml_filtre = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_ucret_filtre = new System.Windows.Forms.TextBox();
            this.btn_xml_den_excel = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btn_xml_den_treeview = new System.Windows.Forms.Button();
            this.treeView1 = new System.Windows.Forms.TreeView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_dataset_ile_olustur
            // 
            this.btn_dataset_ile_olustur.Location = new System.Drawing.Point(12, 12);
            this.btn_dataset_ile_olustur.Name = "btn_dataset_ile_olustur";
            this.btn_dataset_ile_olustur.Size = new System.Drawing.Size(247, 70);
            this.btn_dataset_ile_olustur.TabIndex = 0;
            this.btn_dataset_ile_olustur.Text = "DataSet ile XML Dosyası Oluştur";
            this.btn_dataset_ile_olustur.UseVisualStyleBackColor = true;
            this.btn_dataset_ile_olustur.Click += new System.EventHandler(this.Btn_dataset_ile_olustur_Click);
            // 
            // btn_xml_den_dataset
            // 
            this.btn_xml_den_dataset.Location = new System.Drawing.Point(12, 88);
            this.btn_xml_den_dataset.Name = "btn_xml_den_dataset";
            this.btn_xml_den_dataset.Size = new System.Drawing.Size(247, 70);
            this.btn_xml_den_dataset.TabIndex = 1;
            this.btn_xml_den_dataset.Text = "XML ile DataSet Dosyası Oluştur";
            this.btn_xml_den_dataset.UseVisualStyleBackColor = true;
            this.btn_xml_den_dataset.Click += new System.EventHandler(this.Button1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(265, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(388, 146);
            this.dataGridView1.TabIndex = 2;
            // 
            // btn_xml_de_ara
            // 
            this.btn_xml_de_ara.Location = new System.Drawing.Point(12, 164);
            this.btn_xml_de_ara.Name = "btn_xml_de_ara";
            this.btn_xml_de_ara.Size = new System.Drawing.Size(247, 70);
            this.btn_xml_de_ara.TabIndex = 3;
            this.btn_xml_de_ara.Text = "XML Dosyada Arama Yapmak";
            this.btn_xml_de_ara.UseVisualStyleBackColor = true;
            this.btn_xml_de_ara.Click += new System.EventHandler(this.Btn_xml_de_ara_Click);
            // 
            // txt_aranacak_metin
            // 
            this.txt_aranacak_metin.Location = new System.Drawing.Point(268, 180);
            this.txt_aranacak_metin.Name = "txt_aranacak_metin";
            this.txt_aranacak_metin.Size = new System.Drawing.Size(247, 20);
            this.txt_aranacak_metin.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(265, 164);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Aranacak Metin";
            // 
            // lbl_sonuc
            // 
            this.lbl_sonuc.AutoSize = true;
            this.lbl_sonuc.Location = new System.Drawing.Point(265, 203);
            this.lbl_sonuc.Name = "lbl_sonuc";
            this.lbl_sonuc.Size = new System.Drawing.Size(47, 13);
            this.lbl_sonuc.TabIndex = 6;
            this.lbl_sonuc.Text = "Sonuç : ";
            // 
            // btn_xml_filtre
            // 
            this.btn_xml_filtre.Location = new System.Drawing.Point(12, 240);
            this.btn_xml_filtre.Name = "btn_xml_filtre";
            this.btn_xml_filtre.Size = new System.Drawing.Size(247, 70);
            this.btn_xml_filtre.TabIndex = 7;
            this.btn_xml_filtre.Text = "XML Dosyada Filtre Vermek";
            this.btn_xml_filtre.UseVisualStyleBackColor = true;
            this.btn_xml_filtre.Click += new System.EventHandler(this.Btn_xml_filtre_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(265, 262);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(388, 146);
            this.dataGridView2.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(262, 240);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Proje Ücreti Filtre";
            // 
            // txt_ucret_filtre
            // 
            this.txt_ucret_filtre.Location = new System.Drawing.Point(350, 236);
            this.txt_ucret_filtre.Name = "txt_ucret_filtre";
            this.txt_ucret_filtre.Size = new System.Drawing.Size(247, 20);
            this.txt_ucret_filtre.TabIndex = 9;
            // 
            // btn_xml_den_excel
            // 
            this.btn_xml_den_excel.Enabled = false;
            this.btn_xml_den_excel.Location = new System.Drawing.Point(12, 423);
            this.btn_xml_den_excel.Name = "btn_xml_den_excel";
            this.btn_xml_den_excel.Size = new System.Drawing.Size(247, 70);
            this.btn_xml_den_excel.TabIndex = 11;
            this.btn_xml_den_excel.Text = "XML den EXCEL Oluşturma";
            this.btn_xml_den_excel.UseVisualStyleBackColor = true;
            this.btn_xml_den_excel.Click += new System.EventHandler(this.Btn_xml_den_excel_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 499);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(247, 70);
            this.button1.TabIndex = 12;
            this.button1.Text = "EXCEL den XML Oluşturma";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click_1);
            // 
            // btn_xml_den_treeview
            // 
            this.btn_xml_den_treeview.Location = new System.Drawing.Point(678, 12);
            this.btn_xml_den_treeview.Name = "btn_xml_den_treeview";
            this.btn_xml_den_treeview.Size = new System.Drawing.Size(247, 70);
            this.btn_xml_den_treeview.TabIndex = 13;
            this.btn_xml_den_treeview.Text = "XML den TreeView Oluşturma";
            this.btn_xml_den_treeview.UseVisualStyleBackColor = true;
            this.btn_xml_den_treeview.Click += new System.EventHandler(this.Btn_xml_den_treeview_Click);
            // 
            // treeView1
            // 
            this.treeView1.Location = new System.Drawing.Point(931, 12);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(216, 146);
            this.treeView1.TabIndex = 14;
            // 
            // XML_Diger_Islemler
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1374, 701);
            this.Controls.Add(this.treeView1);
            this.Controls.Add(this.btn_xml_den_treeview);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btn_xml_den_excel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_ucret_filtre);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.btn_xml_filtre);
            this.Controls.Add(this.lbl_sonuc);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_aranacak_metin);
            this.Controls.Add(this.btn_xml_de_ara);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btn_xml_den_dataset);
            this.Controls.Add(this.btn_dataset_ile_olustur);
            this.Name = "XML_Diger_Islemler";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "XML_Diger_Islemler";
            this.Load += new System.EventHandler(this.XML_Diger_Islemler_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_dataset_ile_olustur;
        private System.Windows.Forms.Button btn_xml_den_dataset;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btn_xml_de_ara;
        private System.Windows.Forms.TextBox txt_aranacak_metin;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_sonuc;
        private System.Windows.Forms.Button btn_xml_filtre;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_ucret_filtre;
        private System.Windows.Forms.Button btn_xml_den_excel;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btn_xml_den_treeview;
        private System.Windows.Forms.TreeView treeView1;
    }
}