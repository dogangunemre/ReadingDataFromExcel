﻿namespace mustafabukulmez_com_dersler._038_Kredi_Karti_Bilgileri
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.label12 = new System.Windows.Forms.Label();
            this.btn_kontrol = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_card_no = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl_kart_turu = new System.Windows.Forms.Label();
            this.lbl_bin_kodu = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lbl_hesap_no = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lbl_kontrol_sayi = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.linkLabel1.Location = new System.Drawing.Point(31, 261);
            this.linkLabel1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(573, 17);
            this.linkLabel1.TabIndex = 18;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "https://mustafabukulmez.com/2020/04/09/c-kredi-karti-numarasindaki-bilgiler/";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(30, 232);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(351, 24);
            this.label12.TabIndex = 17;
            this.label12.Text = "C# Kredi Kartı Numarasındaki Bilgiler";
            // 
            // btn_kontrol
            // 
            this.btn_kontrol.Location = new System.Drawing.Point(334, 20);
            this.btn_kontrol.Name = "btn_kontrol";
            this.btn_kontrol.Size = new System.Drawing.Size(75, 23);
            this.btn_kontrol.TabIndex = 15;
            this.btn_kontrol.Text = "Kontol Et";
            this.btn_kontrol.UseVisualStyleBackColor = true;
            this.btn_kontrol.Click += new System.EventHandler(this.btn_kontrol_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "Kredi Kart No";
            // 
            // txt_card_no
            // 
            this.txt_card_no.Location = new System.Drawing.Point(121, 21);
            this.txt_card_no.Name = "txt_card_no";
            this.txt_card_no.Size = new System.Drawing.Size(207, 20);
            this.txt_card_no.TabIndex = 13;
            this.txt_card_no.Text = "1234-5678-9876-5432";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(44, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 13);
            this.label2.TabIndex = 19;
            this.label2.Text = "Kart Türü";
            // 
            // lbl_kart_turu
            // 
            this.lbl_kart_turu.AutoSize = true;
            this.lbl_kart_turu.Location = new System.Drawing.Point(137, 84);
            this.lbl_kart_turu.Name = "lbl_kart_turu";
            this.lbl_kart_turu.Size = new System.Drawing.Size(16, 13);
            this.lbl_kart_turu.TabIndex = 20;
            this.lbl_kart_turu.Text = "...";
            // 
            // lbl_bin_kodu
            // 
            this.lbl_bin_kodu.AutoSize = true;
            this.lbl_bin_kodu.Location = new System.Drawing.Point(137, 108);
            this.lbl_bin_kodu.Name = "lbl_bin_kodu";
            this.lbl_bin_kodu.Size = new System.Drawing.Size(16, 13);
            this.lbl_bin_kodu.TabIndex = 22;
            this.lbl_bin_kodu.Text = "...";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(44, 108);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 13);
            this.label5.TabIndex = 21;
            this.label5.Text = "BIN Kodu";
            // 
            // lbl_hesap_no
            // 
            this.lbl_hesap_no.AutoSize = true;
            this.lbl_hesap_no.Location = new System.Drawing.Point(137, 132);
            this.lbl_hesap_no.Name = "lbl_hesap_no";
            this.lbl_hesap_no.Size = new System.Drawing.Size(16, 13);
            this.lbl_hesap_no.TabIndex = 24;
            this.lbl_hesap_no.Text = "...";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(44, 132);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 13);
            this.label7.TabIndex = 23;
            this.label7.Text = "Hesap Numarası";
            // 
            // lbl_kontrol_sayi
            // 
            this.lbl_kontrol_sayi.AutoSize = true;
            this.lbl_kontrol_sayi.Location = new System.Drawing.Point(137, 156);
            this.lbl_kontrol_sayi.Name = "lbl_kontrol_sayi";
            this.lbl_kontrol_sayi.Size = new System.Drawing.Size(16, 13);
            this.lbl_kontrol_sayi.TabIndex = 26;
            this.lbl_kontrol_sayi.Text = "...";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(44, 156);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(70, 13);
            this.label9.TabIndex = 25;
            this.label9.Text = "Kontrol Sayısı";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 359);
            this.Controls.Add(this.lbl_kontrol_sayi);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lbl_hesap_no);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lbl_bin_kodu);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lbl_kart_turu);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.btn_kontrol);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_card_no);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btn_kontrol;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_card_no;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbl_kart_turu;
        private System.Windows.Forms.Label lbl_bin_kodu;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbl_hesap_no;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbl_kontrol_sayi;
        private System.Windows.Forms.Label label9;
    }
}