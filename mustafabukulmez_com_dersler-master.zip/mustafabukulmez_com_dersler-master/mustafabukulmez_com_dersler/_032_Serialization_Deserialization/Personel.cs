﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mustafabukulmez_com_dersler._032_Serialization_Deserialization
{
    public class Personel
    {
        public string Adi { get; set; }
        public string Soyadi { get; set; }
        public string Telefon { get; set; }
        public string  Mail_Adres { get; set; }
    }
}
