﻿namespace mustafabukulmez_com_dersler._027_Listboxlar_Arasi_Surukle_Birak
{
    //https://mustafabukulmez.com/2019/12/07/c-listboxlar-arasi-drag-drop-surukle-birak/
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.listBox4 = new System.Windows.Forms.ListBox();
            this.btn_sifirla = new System.Windows.Forms.Button();
            this.listBox5 = new System.Windows.Forms.ListBox();
            this.listBox6 = new System.Windows.Forms.ListBox();
            this.listBox7 = new System.Windows.Forms.ListBox();
            this.listBox8 = new System.Windows.Forms.ListBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.listBox9 = new System.Windows.Forms.ListBox();
            this.listBox10 = new System.Windows.Forms.ListBox();
            this.listBox11 = new System.Windows.Forms.ListBox();
            this.listBox12 = new System.Windows.Forms.ListBox();
            this.listBox13 = new System.Windows.Forms.ListBox();
            this.listBox14 = new System.Windows.Forms.ListBox();
            this.listBox15 = new System.Windows.Forms.ListBox();
            this.listBox16 = new System.Windows.Forms.ListBox();
            this.listBox17 = new System.Windows.Forms.ListBox();
            this.listBox18 = new System.Windows.Forms.ListBox();
            this.listBox19 = new System.Windows.Forms.ListBox();
            this.listBox20 = new System.Windows.Forms.ListBox();
            this.listBox21 = new System.Windows.Forms.ListBox();
            this.listBox22 = new System.Windows.Forms.ListBox();
            this.listBox23 = new System.Windows.Forms.ListBox();
            this.listBox24 = new System.Windows.Forms.ListBox();
            this.listBox25 = new System.Windows.Forms.ListBox();
            this.listBox26 = new System.Windows.Forms.ListBox();
            this.listBox27 = new System.Windows.Forms.ListBox();
            this.listBox28 = new System.Windows.Forms.ListBox();
            this.listBox29 = new System.Windows.Forms.ListBox();
            this.listBox30 = new System.Windows.Forms.ListBox();
            this.listBox31 = new System.Windows.Forms.ListBox();
            this.listBox32 = new System.Windows.Forms.ListBox();
            this.listBox33 = new System.Windows.Forms.ListBox();
            this.listBox34 = new System.Windows.Forms.ListBox();
            this.listBox35 = new System.Windows.Forms.ListBox();
            this.listBox36 = new System.Windows.Forms.ListBox();
            this.listBox37 = new System.Windows.Forms.ListBox();
            this.listBox38 = new System.Windows.Forms.ListBox();
            this.listBox39 = new System.Windows.Forms.ListBox();
            this.listBox40 = new System.Windows.Forms.ListBox();
            this.listBox41 = new System.Windows.Forms.ListBox();
            this.listBox42 = new System.Windows.Forms.ListBox();
            this.listBox43 = new System.Windows.Forms.ListBox();
            this.listBox44 = new System.Windows.Forms.ListBox();
            this.listBox45 = new System.Windows.Forms.ListBox();
            this.listBox46 = new System.Windows.Forms.ListBox();
            this.listBox47 = new System.Windows.Forms.ListBox();
            this.listBox48 = new System.Windows.Forms.ListBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_esit_dagit = new System.Windows.Forms.Button();
            this.btn_rastgele_dagit = new System.Windows.Forms.Button();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.label12 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.AllowDrop = true;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(12, 7);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(136, 108);
            this.listBox1.TabIndex = 0;
            this.listBox1.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox1.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox1.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // https://mustafabukulmez.com/2019/12/07/c-listboxlar-arasi-drag-drop-surukle-birak/
            // listBox2
            // 
            this.listBox2.AllowDrop = true;
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(154, 7);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(136, 108);
            this.listBox2.TabIndex = 1;
            this.listBox2.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox2.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox2.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox3
            // 
            this.listBox3.AllowDrop = true;
            this.listBox3.FormattingEnabled = true;
            this.listBox3.Location = new System.Drawing.Point(296, 7);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(136, 108);
            this.listBox3.TabIndex = 2;
            this.listBox3.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox3.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox3.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox4
            // 
            this.listBox4.AllowDrop = true;
            this.listBox4.FormattingEnabled = true;
            this.listBox4.Location = new System.Drawing.Point(438, 7);
            this.listBox4.Name = "listBox4";
            this.listBox4.Size = new System.Drawing.Size(136, 108);
            this.listBox4.TabIndex = 3;
            this.listBox4.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox4.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox4.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // btn_sifirla
            // 
            this.btn_sifirla.Dock = System.Windows.Forms.DockStyle.Left;
            this.btn_sifirla.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_sifirla.Location = new System.Drawing.Point(0, 0);
            this.btn_sifirla.Name = "btn_sifirla";
            this.btn_sifirla.Size = new System.Drawing.Size(257, 49);
            this.btn_sifirla.TabIndex = 4;
            this.btn_sifirla.Text = "Hepsini Sıfırla";
            this.btn_sifirla.UseVisualStyleBackColor = true;
            this.btn_sifirla.Click += new System.EventHandler(this.btn_sifirla_Click);
            // 
            // listBox5
            // 
            this.listBox5.AllowDrop = true;
            this.listBox5.FormattingEnabled = true;
            this.listBox5.Location = new System.Drawing.Point(580, 7);
            this.listBox5.Name = "listBox5";
            this.listBox5.Size = new System.Drawing.Size(136, 108);
            this.listBox5.TabIndex = 11;
            this.listBox5.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox5.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox5.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox6
            // 
            this.listBox6.AllowDrop = true;
            this.listBox6.FormattingEnabled = true;
            this.listBox6.Location = new System.Drawing.Point(722, 7);
            this.listBox6.Name = "listBox6";
            this.listBox6.Size = new System.Drawing.Size(136, 108);
            this.listBox6.TabIndex = 10;
            this.listBox6.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox6.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox6.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox7
            // 
            this.listBox7.AllowDrop = true;
            this.listBox7.FormattingEnabled = true;
            this.listBox7.Location = new System.Drawing.Point(864, 7);
            this.listBox7.Name = "listBox7";
            this.listBox7.Size = new System.Drawing.Size(136, 108);
            this.listBox7.TabIndex = 9;
            this.listBox7.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox7.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox7.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox8
            // 
            this.listBox8.AllowDrop = true;
            this.listBox8.FormattingEnabled = true;
            this.listBox8.Location = new System.Drawing.Point(1006, 7);
            this.listBox8.Name = "listBox8";
            this.listBox8.Size = new System.Drawing.Size(136, 108);
            this.listBox8.TabIndex = 8;
            this.listBox8.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox8.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox8.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.listBox1);
            this.panel1.Controls.Add(this.listBox2);
            this.panel1.Controls.Add(this.listBox3);
            this.panel1.Controls.Add(this.listBox4);
            this.panel1.Controls.Add(this.listBox5);
            this.panel1.Controls.Add(this.listBox6);
            this.panel1.Controls.Add(this.listBox7);
            this.panel1.Controls.Add(this.listBox8);
            this.panel1.Controls.Add(this.listBox9);
            this.panel1.Controls.Add(this.listBox10);
            this.panel1.Controls.Add(this.listBox11);
            this.panel1.Controls.Add(this.listBox12);
            this.panel1.Controls.Add(this.listBox13);
            this.panel1.Controls.Add(this.listBox14);
            this.panel1.Controls.Add(this.listBox15);
            this.panel1.Controls.Add(this.listBox16);
            this.panel1.Controls.Add(this.listBox17);
            this.panel1.Controls.Add(this.listBox18);
            this.panel1.Controls.Add(this.listBox19);
            this.panel1.Controls.Add(this.listBox20);
            this.panel1.Controls.Add(this.listBox21);
            this.panel1.Controls.Add(this.listBox22);
            this.panel1.Controls.Add(this.listBox23);
            this.panel1.Controls.Add(this.listBox24);
            this.panel1.Controls.Add(this.listBox25);
            this.panel1.Controls.Add(this.listBox26);
            this.panel1.Controls.Add(this.listBox27);
            this.panel1.Controls.Add(this.listBox28);
            this.panel1.Controls.Add(this.listBox29);
            this.panel1.Controls.Add(this.listBox30);
            this.panel1.Controls.Add(this.listBox31);
            this.panel1.Controls.Add(this.listBox32);
            this.panel1.Controls.Add(this.listBox33);
            this.panel1.Controls.Add(this.listBox34);
            this.panel1.Controls.Add(this.listBox35);
            this.panel1.Controls.Add(this.listBox36);
            this.panel1.Controls.Add(this.listBox37);
            this.panel1.Controls.Add(this.listBox38);
            this.panel1.Controls.Add(this.listBox39);
            this.panel1.Controls.Add(this.listBox40);
            this.panel1.Controls.Add(this.listBox41);
            this.panel1.Controls.Add(this.listBox42);
            this.panel1.Controls.Add(this.listBox43);
            this.panel1.Controls.Add(this.listBox44);
            this.panel1.Controls.Add(this.listBox45);
            this.panel1.Controls.Add(this.listBox46);
            this.panel1.Controls.Add(this.listBox47);
            this.panel1.Controls.Add(this.listBox48);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 124);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1154, 700);
            this.panel1.TabIndex = 0;
            // 
            // listBox9
            // 
            this.listBox9.AllowDrop = true;
            this.listBox9.FormattingEnabled = true;
            this.listBox9.Location = new System.Drawing.Point(12, 121);
            this.listBox9.Name = "listBox9";
            this.listBox9.Size = new System.Drawing.Size(136, 108);
            this.listBox9.TabIndex = 27;
            this.listBox9.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox9.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox9.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox9.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox10
            // 
            this.listBox10.AllowDrop = true;
            this.listBox10.FormattingEnabled = true;
            this.listBox10.Location = new System.Drawing.Point(154, 121);
            this.listBox10.Name = "listBox10";
            this.listBox10.Size = new System.Drawing.Size(136, 108);
            this.listBox10.TabIndex = 26;
            this.listBox10.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox10.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox10.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox10.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox11
            // 
            this.listBox11.AllowDrop = true;
            this.listBox11.FormattingEnabled = true;
            this.listBox11.Location = new System.Drawing.Point(296, 121);
            this.listBox11.Name = "listBox11";
            this.listBox11.Size = new System.Drawing.Size(136, 108);
            this.listBox11.TabIndex = 25;
            this.listBox11.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox11.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox11.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox11.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox12
            // 
            this.listBox12.AllowDrop = true;
            this.listBox12.FormattingEnabled = true;
            this.listBox12.Location = new System.Drawing.Point(438, 121);
            this.listBox12.Name = "listBox12";
            this.listBox12.Size = new System.Drawing.Size(136, 108);
            this.listBox12.TabIndex = 24;
            this.listBox12.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox12.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox12.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox12.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox13
            // 
            this.listBox13.AllowDrop = true;
            this.listBox13.FormattingEnabled = true;
            this.listBox13.Location = new System.Drawing.Point(580, 121);
            this.listBox13.Name = "listBox13";
            this.listBox13.Size = new System.Drawing.Size(136, 108);
            this.listBox13.TabIndex = 19;
            this.listBox13.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox13.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox13.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox13.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox14
            // 
            this.listBox14.AllowDrop = true;
            this.listBox14.FormattingEnabled = true;
            this.listBox14.Location = new System.Drawing.Point(722, 121);
            this.listBox14.Name = "listBox14";
            this.listBox14.Size = new System.Drawing.Size(136, 108);
            this.listBox14.TabIndex = 18;
            this.listBox14.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox14.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox14.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox14.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox15
            // 
            this.listBox15.AllowDrop = true;
            this.listBox15.FormattingEnabled = true;
            this.listBox15.Location = new System.Drawing.Point(864, 121);
            this.listBox15.Name = "listBox15";
            this.listBox15.Size = new System.Drawing.Size(136, 108);
            this.listBox15.TabIndex = 17;
            this.listBox15.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox15.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox15.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox15.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox16
            // 
            this.listBox16.AllowDrop = true;
            this.listBox16.FormattingEnabled = true;
            this.listBox16.Location = new System.Drawing.Point(1006, 121);
            this.listBox16.Name = "listBox16";
            this.listBox16.Size = new System.Drawing.Size(136, 108);
            this.listBox16.TabIndex = 16;
            this.listBox16.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox16.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox16.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox16.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // https://mustafabukulmez.com/2019/12/07/c-listboxlar-arasi-drag-drop-surukle-birak/
            // listBox17
            // 
            this.listBox17.AllowDrop = true;
            this.listBox17.FormattingEnabled = true;
            this.listBox17.Location = new System.Drawing.Point(12, 235);
            this.listBox17.Name = "listBox17";
            this.listBox17.Size = new System.Drawing.Size(136, 108);
            this.listBox17.TabIndex = 43;
            this.listBox17.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox17.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox17.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox17.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox18
            // 
            this.listBox18.AllowDrop = true;
            this.listBox18.FormattingEnabled = true;
            this.listBox18.Location = new System.Drawing.Point(154, 235);
            this.listBox18.Name = "listBox18";
            this.listBox18.Size = new System.Drawing.Size(136, 108);
            this.listBox18.TabIndex = 42;
            this.listBox18.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox18.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox18.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox18.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox19
            // 
            this.listBox19.AllowDrop = true;
            this.listBox19.FormattingEnabled = true;
            this.listBox19.Location = new System.Drawing.Point(296, 235);
            this.listBox19.Name = "listBox19";
            this.listBox19.Size = new System.Drawing.Size(136, 108);
            this.listBox19.TabIndex = 41;
            this.listBox19.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox19.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox19.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox19.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox20
            // 
            this.listBox20.AllowDrop = true;
            this.listBox20.FormattingEnabled = true;
            this.listBox20.Location = new System.Drawing.Point(438, 235);
            this.listBox20.Name = "listBox20";
            this.listBox20.Size = new System.Drawing.Size(136, 108);
            this.listBox20.TabIndex = 40;
            this.listBox20.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox20.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox20.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox20.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox21
            // 
            this.listBox21.AllowDrop = true;
            this.listBox21.FormattingEnabled = true;
            this.listBox21.Location = new System.Drawing.Point(580, 235);
            this.listBox21.Name = "listBox21";
            this.listBox21.Size = new System.Drawing.Size(136, 108);
            this.listBox21.TabIndex = 35;
            this.listBox21.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox21.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox21.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox21.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox22
            // 
            this.listBox22.AllowDrop = true;
            this.listBox22.FormattingEnabled = true;
            this.listBox22.Location = new System.Drawing.Point(722, 235);
            this.listBox22.Name = "listBox22";
            this.listBox22.Size = new System.Drawing.Size(136, 108);
            this.listBox22.TabIndex = 34;
            this.listBox22.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox22.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox22.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox22.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox23
            // 
            this.listBox23.AllowDrop = true;
            this.listBox23.FormattingEnabled = true;
            this.listBox23.Location = new System.Drawing.Point(864, 235);
            this.listBox23.Name = "listBox23";
            this.listBox23.Size = new System.Drawing.Size(136, 108);
            this.listBox23.TabIndex = 33;
            this.listBox23.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox23.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox23.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox23.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox24
            // 
            this.listBox24.AllowDrop = true;
            this.listBox24.FormattingEnabled = true;
            this.listBox24.Location = new System.Drawing.Point(1006, 235);
            this.listBox24.Name = "listBox24";
            this.listBox24.Size = new System.Drawing.Size(136, 108);
            this.listBox24.TabIndex = 32;
            this.listBox24.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox24.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox24.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox24.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox25
            // 
            this.listBox25.AllowDrop = true;
            this.listBox25.FormattingEnabled = true;
            this.listBox25.Location = new System.Drawing.Point(12, 349);
            this.listBox25.Name = "listBox25";
            this.listBox25.Size = new System.Drawing.Size(136, 108);
            this.listBox25.TabIndex = 47;
            this.listBox25.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox25.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox25.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox25.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox26
            // 
            this.listBox26.AllowDrop = true;
            this.listBox26.FormattingEnabled = true;
            this.listBox26.Location = new System.Drawing.Point(154, 349);
            this.listBox26.Name = "listBox26";
            this.listBox26.Size = new System.Drawing.Size(136, 108);
            this.listBox26.TabIndex = 46;
            this.listBox26.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox26.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox26.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox26.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox27
            // 
            this.listBox27.AllowDrop = true;
            this.listBox27.FormattingEnabled = true;
            this.listBox27.Location = new System.Drawing.Point(296, 349);
            this.listBox27.Name = "listBox27";
            this.listBox27.Size = new System.Drawing.Size(136, 108);
            this.listBox27.TabIndex = 45;
            this.listBox27.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox27.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox27.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox27.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox28
            // 
            this.listBox28.AllowDrop = true;
            this.listBox28.FormattingEnabled = true;
            this.listBox28.Location = new System.Drawing.Point(438, 349);
            this.listBox28.Name = "listBox28";
            this.listBox28.Size = new System.Drawing.Size(136, 108);
            this.listBox28.TabIndex = 44;
            this.listBox28.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox28.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox28.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox28.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox29
            // 
            this.listBox29.AllowDrop = true;
            this.listBox29.FormattingEnabled = true;
            this.listBox29.Location = new System.Drawing.Point(580, 349);
            this.listBox29.Name = "listBox29";
            this.listBox29.Size = new System.Drawing.Size(136, 108);
            this.listBox29.TabIndex = 39;
            this.listBox29.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox29.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox29.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox29.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox30
            // 
            this.listBox30.AllowDrop = true;
            this.listBox30.FormattingEnabled = true;
            this.listBox30.Location = new System.Drawing.Point(722, 349);
            this.listBox30.Name = "listBox30";
            this.listBox30.Size = new System.Drawing.Size(136, 108);
            this.listBox30.TabIndex = 38;
            this.listBox30.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox30.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox30.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox30.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox31
            // 
            this.listBox31.AllowDrop = true;
            this.listBox31.FormattingEnabled = true;
            this.listBox31.Location = new System.Drawing.Point(864, 349);
            this.listBox31.Name = "listBox31";
            this.listBox31.Size = new System.Drawing.Size(136, 108);
            this.listBox31.TabIndex = 37;
            this.listBox31.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox31.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox31.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox31.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox32
            // 
            this.listBox32.AllowDrop = true;
            this.listBox32.FormattingEnabled = true;
            this.listBox32.Location = new System.Drawing.Point(1006, 349);
            this.listBox32.Name = "listBox32";
            this.listBox32.Size = new System.Drawing.Size(136, 108);
            this.listBox32.TabIndex = 36;
            this.listBox32.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox32.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox32.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox32.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // https://mustafabukulmez.com/2019/12/07/c-listboxlar-arasi-drag-drop-surukle-birak/
            // listBox33
            // 
            this.listBox33.AllowDrop = true;
            this.listBox33.FormattingEnabled = true;
            this.listBox33.Location = new System.Drawing.Point(12, 463);
            this.listBox33.Name = "listBox33";
            this.listBox33.Size = new System.Drawing.Size(136, 108);
            this.listBox33.TabIndex = 31;
            this.listBox33.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox33.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox33.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox33.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox34
            // 
            this.listBox34.AllowDrop = true;
            this.listBox34.FormattingEnabled = true;
            this.listBox34.Location = new System.Drawing.Point(154, 463);
            this.listBox34.Name = "listBox34";
            this.listBox34.Size = new System.Drawing.Size(136, 108);
            this.listBox34.TabIndex = 30;
            this.listBox34.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox34.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox34.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox34.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox35
            // 
            this.listBox35.AllowDrop = true;
            this.listBox35.FormattingEnabled = true;
            this.listBox35.Location = new System.Drawing.Point(296, 463);
            this.listBox35.Name = "listBox35";
            this.listBox35.Size = new System.Drawing.Size(136, 108);
            this.listBox35.TabIndex = 29;
            this.listBox35.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox35.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox35.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox35.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox36
            // 
            this.listBox36.AllowDrop = true;
            this.listBox36.FormattingEnabled = true;
            this.listBox36.Location = new System.Drawing.Point(438, 463);
            this.listBox36.Name = "listBox36";
            this.listBox36.Size = new System.Drawing.Size(136, 108);
            this.listBox36.TabIndex = 28;
            this.listBox36.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox36.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox36.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox36.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox37
            // 
            this.listBox37.AllowDrop = true;
            this.listBox37.FormattingEnabled = true;
            this.listBox37.Location = new System.Drawing.Point(580, 463);
            this.listBox37.Name = "listBox37";
            this.listBox37.Size = new System.Drawing.Size(136, 108);
            this.listBox37.TabIndex = 23;
            this.listBox37.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox37.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox37.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox37.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox38
            // 
            this.listBox38.AllowDrop = true;
            this.listBox38.FormattingEnabled = true;
            this.listBox38.Location = new System.Drawing.Point(722, 463);
            this.listBox38.Name = "listBox38";
            this.listBox38.Size = new System.Drawing.Size(136, 108);
            this.listBox38.TabIndex = 22;
            this.listBox38.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox38.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox38.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox38.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox39
            // 
            this.listBox39.AllowDrop = true;
            this.listBox39.FormattingEnabled = true;
            this.listBox39.Location = new System.Drawing.Point(864, 463);
            this.listBox39.Name = "listBox39";
            this.listBox39.Size = new System.Drawing.Size(136, 108);
            this.listBox39.TabIndex = 21;
            this.listBox39.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox39.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox39.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox39.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox40
            // 
            this.listBox40.AllowDrop = true;
            this.listBox40.FormattingEnabled = true;
            this.listBox40.Location = new System.Drawing.Point(1006, 463);
            this.listBox40.Name = "listBox40";
            this.listBox40.Size = new System.Drawing.Size(136, 108);
            this.listBox40.TabIndex = 20;
            this.listBox40.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox40.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox40.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox40.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox41
            // 
            this.listBox41.AllowDrop = true;
            this.listBox41.FormattingEnabled = true;
            this.listBox41.Location = new System.Drawing.Point(12, 577);
            this.listBox41.Name = "listBox41";
            this.listBox41.Size = new System.Drawing.Size(136, 108);
            this.listBox41.TabIndex = 15;
            this.listBox41.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox41.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox41.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox41.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox42
            // 
            this.listBox42.AllowDrop = true;
            this.listBox42.FormattingEnabled = true;
            this.listBox42.Location = new System.Drawing.Point(154, 577);
            this.listBox42.Name = "listBox42";
            this.listBox42.Size = new System.Drawing.Size(136, 108);
            this.listBox42.TabIndex = 14;
            this.listBox42.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox42.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox42.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox42.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox43
            // 
            this.listBox43.AllowDrop = true;
            this.listBox43.FormattingEnabled = true;
            this.listBox43.Location = new System.Drawing.Point(296, 577);
            this.listBox43.Name = "listBox43";
            this.listBox43.Size = new System.Drawing.Size(136, 108);
            this.listBox43.TabIndex = 13;
            this.listBox43.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox43.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox43.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox43.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox44
            // 
            this.listBox44.AllowDrop = true;
            this.listBox44.FormattingEnabled = true;
            this.listBox44.Location = new System.Drawing.Point(438, 577);
            this.listBox44.Name = "listBox44";
            this.listBox44.Size = new System.Drawing.Size(136, 108);
            this.listBox44.TabIndex = 12;
            this.listBox44.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox44.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox44.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox44.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // https://mustafabukulmez.com/2019/12/07/c-listboxlar-arasi-drag-drop-surukle-birak/
            // listBox45
            // 
            this.listBox45.AllowDrop = true;
            this.listBox45.FormattingEnabled = true;
            this.listBox45.Location = new System.Drawing.Point(580, 577);
            this.listBox45.Name = "listBox45";
            this.listBox45.Size = new System.Drawing.Size(136, 108);
            this.listBox45.TabIndex = 7;
            this.listBox45.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox45.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox45.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox45.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox46
            // 
            this.listBox46.AllowDrop = true;
            this.listBox46.FormattingEnabled = true;
            this.listBox46.Location = new System.Drawing.Point(722, 577);
            this.listBox46.Name = "listBox46";
            this.listBox46.Size = new System.Drawing.Size(136, 108);
            this.listBox46.TabIndex = 6;
            this.listBox46.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox46.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox46.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox46.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox47
            // 
            this.listBox47.AllowDrop = true;
            this.listBox47.FormattingEnabled = true;
            this.listBox47.Location = new System.Drawing.Point(864, 577);
            this.listBox47.Name = "listBox47";
            this.listBox47.Size = new System.Drawing.Size(136, 108);
            this.listBox47.TabIndex = 5;
            this.listBox47.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox47.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox47.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox47.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // listBox48
            // 
            this.listBox48.AllowDrop = true;
            this.listBox48.FormattingEnabled = true;
            this.listBox48.Location = new System.Drawing.Point(1006, 577);
            this.listBox48.Name = "listBox48";
            this.listBox48.Size = new System.Drawing.Size(136, 108);
            this.listBox48.TabIndex = 4;
            this.listBox48.DragDrop += new System.Windows.Forms.DragEventHandler(this.listBox_DragDrop);
            this.listBox48.DragEnter += new System.Windows.Forms.DragEventHandler(this.listBox_DragEnter);
            this.listBox48.DragOver += new System.Windows.Forms.DragEventHandler(this.listBox_DragOver);
            this.listBox48.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseDown);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btn_esit_dagit);
            this.panel2.Controls.Add(this.btn_rastgele_dagit);
            this.panel2.Controls.Add(this.btn_sifirla);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1154, 49);
            this.panel2.TabIndex = 1;
            // 
            // btn_esit_dagit
            // 
            this.btn_esit_dagit.Dock = System.Windows.Forms.DockStyle.Left;
            this.btn_esit_dagit.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_esit_dagit.Location = new System.Drawing.Point(514, 0);
            this.btn_esit_dagit.Name = "btn_esit_dagit";
            this.btn_esit_dagit.Size = new System.Drawing.Size(257, 49);
            this.btn_esit_dagit.TabIndex = 6;
            this.btn_esit_dagit.Text = "Eşit Dağıt";
            this.btn_esit_dagit.UseVisualStyleBackColor = true;
            this.btn_esit_dagit.Click += new System.EventHandler(this.btn_esit_dagit_Click);
            // 
            // btn_rastgele_dagit
            // 
            this.btn_rastgele_dagit.Dock = System.Windows.Forms.DockStyle.Left;
            this.btn_rastgele_dagit.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_rastgele_dagit.Location = new System.Drawing.Point(257, 0);
            this.btn_rastgele_dagit.Name = "btn_rastgele_dagit";
            this.btn_rastgele_dagit.Size = new System.Drawing.Size(257, 49);
            this.btn_rastgele_dagit.TabIndex = 5;
            this.btn_rastgele_dagit.Text = "Rastgele Dağıt";
            this.btn_rastgele_dagit.UseVisualStyleBackColor = true;
            this.btn_rastgele_dagit.Click += new System.EventHandler(this.btn_rastgele_dagit_Click);
            // https://mustafabukulmez.com/2019/12/07/c-listboxlar-arasi-drag-drop-surukle-birak/
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.linkLabel1.Location = new System.Drawing.Point(30, 91);
            this.linkLabel1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(619, 17);
            this.linkLabel1.TabIndex = 14;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "https://mustafabukulmez.com/2019/12/07/c-listboxlar-arasi-drag-drop-surukle-birak" +
    "/";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(29, 62);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(428, 24);
            this.label12.TabIndex = 13;
            this.label12.Text = "C# Listboxlar Arası Drag Drop – Sürükle Bırak";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1154, 824);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.KeyPreview = true;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_sifirla;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.ListBox listBox4;
        private System.Windows.Forms.ListBox listBox5;
        private System.Windows.Forms.ListBox listBox6;
        private System.Windows.Forms.ListBox listBox7;
        private System.Windows.Forms.ListBox listBox8;
        private System.Windows.Forms.ListBox listBox25;
        private System.Windows.Forms.ListBox listBox26;
        private System.Windows.Forms.ListBox listBox27;
        private System.Windows.Forms.ListBox listBox28;
        private System.Windows.Forms.ListBox listBox29;
        private System.Windows.Forms.ListBox listBox30;
        private System.Windows.Forms.ListBox listBox31;
        private System.Windows.Forms.ListBox listBox32;
        private System.Windows.Forms.ListBox listBox33;
        private System.Windows.Forms.ListBox listBox34;
        private System.Windows.Forms.ListBox listBox35;
        private System.Windows.Forms.ListBox listBox36;
        private System.Windows.Forms.ListBox listBox37;
        private System.Windows.Forms.ListBox listBox38;
        private System.Windows.Forms.ListBox listBox39;
        private System.Windows.Forms.ListBox listBox40;
        private System.Windows.Forms.ListBox listBox41;
        private System.Windows.Forms.ListBox listBox42;
        //https://mustafabukulmez.com/2019/12/07/c-listboxlar-arasi-drag-drop-surukle-birak/
        private System.Windows.Forms.ListBox listBox43;
        private System.Windows.Forms.ListBox listBox44;
        private System.Windows.Forms.ListBox listBox45;
        private System.Windows.Forms.ListBox listBox46;
        private System.Windows.Forms.ListBox listBox47;
        private System.Windows.Forms.ListBox listBox48;
        private System.Windows.Forms.ListBox listBox17;
        private System.Windows.Forms.ListBox listBox18;
        private System.Windows.Forms.ListBox listBox19;
        private System.Windows.Forms.ListBox listBox20;
        private System.Windows.Forms.ListBox listBox21;
        private System.Windows.Forms.ListBox listBox22;
        private System.Windows.Forms.ListBox listBox23;
        private System.Windows.Forms.ListBox listBox24;
        private System.Windows.Forms.ListBox listBox9;
        private System.Windows.Forms.ListBox listBox10;
        private System.Windows.Forms.ListBox listBox11;
        private System.Windows.Forms.ListBox listBox12;
        private System.Windows.Forms.ListBox listBox13;
        private System.Windows.Forms.ListBox listBox14;
        private System.Windows.Forms.ListBox listBox15;
        private System.Windows.Forms.ListBox listBox16;
        private System.Windows.Forms.Button btn_rastgele_dagit;
        private System.Windows.Forms.Button btn_esit_dagit;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Label label12;
    }
}
//https://mustafabukulmez.com/2019/12/07/c-listboxlar-arasi-drag-drop-surukle-birak/