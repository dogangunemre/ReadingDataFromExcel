﻿namespace mustafabukulmez_com_dersler._001_Kurulu_Antivirus_Bulmak
{
    partial class AntivirusBulmak
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textEdit1 = new System.Windows.Forms.TextBox();
            this.labelControl1 = new System.Windows.Forms.Label();
            this.labelControl2 = new System.Windows.Forms.Label();
            this.textEdit2 = new System.Windows.Forms.TextBox();
            this.hyperlinkLabelControl1 = new System.Windows.Forms.LinkLabel();
            this.labelControl3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textEdit1
            // 
            this.textEdit1.Location = new System.Drawing.Point(92, 46);
            this.textEdit1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textEdit1.Name = "textEdit1";
            this.textEdit1.Size = new System.Drawing.Size(665, 20);
            this.textEdit1.TabIndex = 0;
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(22, 48);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(16, 15);
            this.labelControl1.TabIndex = 1;
            this.labelControl1.Text = "Adı";
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(22, 71);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(24, 15);
            this.labelControl2.TabIndex = 3;
            this.labelControl2.Text = "Yolu";
            // 
            // textEdit2
            // 
            this.textEdit2.Location = new System.Drawing.Point(92, 68);
            this.textEdit2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textEdit2.Name = "textEdit2";
            this.textEdit2.Size = new System.Drawing.Size(665, 20);
            this.textEdit2.TabIndex = 2;
            // 
            // hyperlinkLabelControl1
            // 
            this.hyperlinkLabelControl1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.hyperlinkLabelControl1.Location = new System.Drawing.Point(10, 102);
            this.hyperlinkLabelControl1.Name = "hyperlinkLabelControl1";
            this.hyperlinkLabelControl1.Size = new System.Drawing.Size(198, 17);
            this.hyperlinkLabelControl1.TabIndex = 4;
            this.hyperlinkLabelControl1.TabStop = true;
            this.hyperlinkLabelControl1.Text = "https://mustafabukulmez.com/";
            // 
            // labelControl3
            // 
            this.labelControl3.Location = new System.Drawing.Point(19, 10);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(381, 20);
            this.labelControl3.TabIndex = 5;
            this.labelControl3.Text = "Bilgisayarda Kurulu Olan Antivirüsü Bulmak";
            // 
            // AntivirusBulmak
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(766, 169);
            this.Controls.Add(this.labelControl3);
            this.Controls.Add(this.hyperlinkLabelControl1);
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.textEdit2);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.textEdit1);
            this.Name = "AntivirusBulmak";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.AntivirusBulmak_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textEdit1;
        private System.Windows.Forms.Label labelControl1;
        private System.Windows.Forms.Label labelControl2;
        private System.Windows.Forms.TextBox textEdit2;
        private System.Windows.Forms.LinkLabel hyperlinkLabelControl1;
        private System.Windows.Forms.Label labelControl3;
    }
}

